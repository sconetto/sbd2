-- ------           AULA 1 EXER 2            ---------- --
--                                                      --
--                    SCRIPT DE DELEÇÃO                 --
--                                                      --
-- Data Criacao ...........: 20/08/2018                 --
-- Autor(es) ..............: João Pedro Sconetto        --
-- Banco de Dados .........: MySQL                      --
-- Base de Dados (nome) ...: aula1exer2                 --
--                                                      --
-- PROJETO => 1 Base de Dados                           --
--         => 10 Tabelas                                --
--                                                      --
-- ---------------------------------------------------- --

USE aula1exer2;

DROP TABLE Supervisiona;
DROP TABLE Possui;
DROP TABLE Realiza;
DROP TABLE Produto;
DROP TABLE Venda;
DROP TABLE Empregado;
DROP TABLE Endereco;
DROP TABLE numeros_telefone;
DROP TABLE Gerente;
DROP TABLE Funcionario;
