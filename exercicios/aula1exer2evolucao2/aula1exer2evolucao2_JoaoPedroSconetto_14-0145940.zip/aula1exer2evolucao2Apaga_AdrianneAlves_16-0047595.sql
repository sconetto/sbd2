-- --------               AULA 1 EXER 2                 ------------ --
--                                                                   --
--                       SCRIPT DE DELEÇÃO                           --
--                                                                   --
-- Data Criacao ...........: 20/08/2018                              --
-- Autor(es) ..............: Adrianne Alves da Silva e               --
--                           João Pedro Sconetto                     --
-- Banco de Dados .........: MySQL                                   --
-- Base de Dados (nome) ...: aula1exer2                              --
--                                                                   --
-- Data Ultima Alteracao ..: 23/08/2018                              --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 7 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --

USE aula1exer2;

DROP TABLE IF EXISTS supervisiona, participa,
VENDA, TELEFONE, EMPREGADO, GERENTE, PRODUTO;
