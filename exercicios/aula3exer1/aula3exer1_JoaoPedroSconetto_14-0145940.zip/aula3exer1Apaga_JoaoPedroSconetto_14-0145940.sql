-- --------                aula3exer1     	            ------------ --
--                                                                   --
--                    SCRIPT DE DELEÇÃO (DDL)                        --
--                                                                   --
-- Data Criacao ...........: 02/09/2018                              --
-- Autor(es) ..............: João Pedro Sconetto                     --
-- Banco de Dados .........: MySQL                                   --
-- Banco de Dados(nome) ...: aula3exer1                              --
--                                                                   --
-- Data Ultima Alteracao ..: 		                                     --
--   			                                                           --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 4 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --

USE aula3exer1;

DROP TABLE IF EXISTS
  alocado,
  Plantonista,
  Especialidade,
  Setor;

  DROP SCHEMA IF EXISTS aula3exer1;
