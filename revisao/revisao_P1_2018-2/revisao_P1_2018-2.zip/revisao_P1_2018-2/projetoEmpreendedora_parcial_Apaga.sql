﻿-- --------        << EMPREENDEDORA >>       ------------ --
-- Data Criacao ...........: 06/05/2018
-- Autor(es) ..............: Diversos
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: bdEmpre
-- 
-- Data Ultima Alteracao ..: 
--   => 
-- 
-- PROJETO => 1 Base de Dados
--         => 4 Tabelas
-- --------------------------------------------------- --

USE bdEmpre;

DROP TABLE CLIENTE;
DROP TABLE PROJETO;
DROP TABLE trabalha;
DROP TABLE PROFISSIONAL;
DROP TABLE telefone;