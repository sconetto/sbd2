-- --------              << EMPREENDEDORA >>            ------------ --
--                                                                   --
--                    SCRIPT DE DELEÇÃO                              --
--                                                                   --
-- Data Criacao ...........: 06/05/2018                              --
-- Autor(es) ..............: João Pedro Sconetto                     --
--                           e diversos                              --
-- Banco de Dados .........: MySQL                                   --
-- Banco de Dados(nome) ...: bdEmpre                                 --
--                                                                   --
-- Data Ultima Alteracao ..: 13/10/2018                              --
--   => Adequação do script para o novo modelo lógico e conceitual   --
--                                                                   --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 5 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --


USE bdEmpre;

DROP TABLE telefoneContato;
DROP TABLE TRABALHA;
DROP TABLE PROJETO;
DROP TABLE CLIENTE;
DROP TABLE PROFISSIONAL;
