﻿-- --------        << EMPREENDEDORA >>       ------------ --
-- Data Criacao ...........: 06/05/2018
-- Autor(es) ..............: Diversos
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: bdEmpre
-- 
-- Data Ultima Alteracao ..: 
--   => 13/10/2018 por Lucas Arthur Lermen - Alterando a forma de apagar tabelas para se adequar ao projeto
-- 
-- PROJETO => 1 Base de Dados
--         => 6 Tabelas
--         => 2 usuários
-- --------------------------------------------------- --

USE bdEmpre;

DROP TABLE IF EXISTS trabalha;
DROP TABLE IF EXISTS TRABALHO;
DROP TABLE IF EXISTS PROJETO;
DROP TABLE IF EXISTS PROFISSIONAL;
DROP TABLE IF EXISTS telefone;
DROP TABLE IF EXISTS CLIENTE;