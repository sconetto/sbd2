﻿-- --------        << EMPREENDEDORA >>       ------------ --
-- Data Criacao ...........: 06/05/2018
-- Autor(es) ..............: Diversos
-- Banco de Dados .........: MySQL
-- Banco de Dados(nome) ...: bdEmpre
-- 
-- Data Ultima Alteracao ..: 13/10/2018 
--   => 
-- 
-- PROJETO => 1 Base de Dados
--         => 6 Tabelas
-- --------------------------------------------------- --

USE bdEmpre;

DROP TABLE trabalha;
DROP TABLE PROFISSIONAL;
DROP TABLE PROJETO;
DROP TABLE CONTRATO;
DROP TABLE telefone;
DROP TABLE CLIENTE;