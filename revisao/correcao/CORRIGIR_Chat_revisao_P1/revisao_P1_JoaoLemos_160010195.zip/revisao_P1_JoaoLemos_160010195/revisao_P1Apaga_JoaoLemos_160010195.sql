

USE bdEmpre;

DROP TABLE if exists telefone;
DROP TABLE if exists trabalha;
DROP TABLE if exists PROJETO;
drop table if exists profissional;
DROP TABLE if exists CLIENTE;