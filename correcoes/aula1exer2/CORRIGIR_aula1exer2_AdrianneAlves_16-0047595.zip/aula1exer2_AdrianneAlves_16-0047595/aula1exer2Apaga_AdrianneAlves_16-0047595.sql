
--                                                                   --
--                    SCRIPT DE REMOÇÃO (DML)                        --
--                                                                   --
-- Data Criacao ...........: 20/08/2018                              --
-- Autor(es) ..............: Adrianne Alves da Silva                 --
-- Banco de Dados .........: MySQL                                   --
-- Banco de Dados(nome) ...: aula1exer2                              --
--                                                                   --
-- Data Ultima Alteracao ..:                                         --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 7 Tabelas                                              --
--                                                                   --

DROP TABLE IF EXISTS supervisiona, participa,VENDA, TELEFONE, EMPREGADO, GERENTE, PRODUTO ;

