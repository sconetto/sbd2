﻿-- --------            aula1exer2	                ------------ --
--                                                                   --
--                    SCRIPT DE EXCLUSÃO (DDL)                        --
--                                                                   --
-- Data Criacao ...........: 23/08/2018                              --
-- Autor(es) ..............: Lucas Arthur Lermen                     --
-- Banco de Dados .........: MySQL                                   --
-- Banco de Dados(nome) ...: aula1exer2evolucao2		     --
--                                                                   --
-- Data Ultima Alteracao ..: 		                             --
--   			                                             --
--                                                                   --
-- PROJETO => 1 Base de Dados                                        --
--         => 8 Tabelas                                              --
--                                                                   --
-- ----------------------------------------------------------------- --




USE aula1exer2evolucao2;


DROP TABLE IF EXISTS
  supervisiona,
  participa,
  VENDA,
  TELEFONE,
  EMPREGADO,
  GERENTE,
  PRODUTO,
  PESSOA;
